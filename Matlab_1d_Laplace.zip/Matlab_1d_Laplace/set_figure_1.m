% set Figure properties
% figure(1);
% x_min=min(x_no);
% x_max=max(x_no);
% y_min=min(y_no);
% y_max=max(y_no);
d=(x_max_bc-x_min_bc)/10;
% axis([x_min_bc-d x_max_bc+d -x_max_bc/10 x_max_bc/5]);
axis([x_min_bc-d x_max_bc+d -0.1 1.1]);
hold on;
% axis equal;
axis off;

