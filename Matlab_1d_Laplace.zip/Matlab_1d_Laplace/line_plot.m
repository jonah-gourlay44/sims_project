function line_plot(x1,y1,x2,y2,line_color,line_width)
x(1)=x1;
x(2)=x2;
y(1)=y1;
y(2)=y2;
plot(x,y,'Color',line_color,'LineWidth',line_width);
