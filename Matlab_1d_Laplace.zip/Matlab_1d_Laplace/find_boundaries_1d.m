function [x_min_bc,x_max_bc]=find_boundaries_1d(x_nodes)
% Find the node (0,0)

x_min_bc=min(x_nodes);
x_max_bc=max(x_nodes);

return;
